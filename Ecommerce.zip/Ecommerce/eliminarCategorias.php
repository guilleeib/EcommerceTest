<?php require 'requires/conexion.php';?>
<?php require 'requires/funcionesCategorias.php';?>	
<?php  include 'includes/header.html';  ?>
<?php  include 'includes/nav.php';  ?>
<?php $chequeo = eliminarCategorias();?>

      


<main class="container">
    <h1>Baja de Producto</h1>
<?php 

	if($chequeo){}
?>
	<div class="alert alert-success">Categoria eliminada con Exito<a href="adminCategorias.php" class="btn btn-light"> Volver a panel </a>
	</div>	
	
</main>

<?php  include 'includes/footer.php';  ?>