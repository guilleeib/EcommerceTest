<?php  include 'includes/header.html';  ?>
<?php  include 'includes/nav.php';  ?>

<main class="container">
    <h1>Alta de Productos</h1>

    <form action="recuperarPass.php" method="post">Email
    <br>
    <input type="text" name="prdNombre" class="form-control">
    <br>
    <input type="submit" value="Agregar marca" class="btn btn-secondary">
    <a href="adminProductos.php" class=btn btn-light>Volver a panel de marcas</a>
    </form>
    </main>
<?php  include 'includes/footer.php';  ?>