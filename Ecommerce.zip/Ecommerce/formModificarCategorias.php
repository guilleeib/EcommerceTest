<?php  
require 'requires/conexion.php';
include 'includes/header.html';  ?>
<?php  include 'includes/nav.php'; 
	   require 'requires/funcionesCategorias.php'; ?>
<?php $verID=verCategoriaPorID();?>

<main class="container">
    <h1>Modificacion de Categorias</h1>

    <form action="modificarCategoria.php" method="post" enctype="multipart/form-data">
        Nombre: <br>
        <input type="text" name="catNombre" value="<?php echo $verID['catNombre'];?>" class="form-control" >
        <br>
    
    <input type="submit" value="Modificar Categoria" class="btn btn-secondary">
    <input type="hidden" name="idCategoria" value="<?php echo $verID['idCategoria']; ?>">
    <a href="adminCategorias.php" class=btn btn-light>Volver a panel de categorias</a>
    </form>