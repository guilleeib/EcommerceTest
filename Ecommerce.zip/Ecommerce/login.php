<?php

require "requires/conexion.php";
require "requires/funcionesUsuarios.php";

 $idUsuario=$_GET['idUsuario'];
 login();
 ?>
s