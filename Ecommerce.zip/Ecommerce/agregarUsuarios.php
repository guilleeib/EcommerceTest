<?php require 'requires/conexion.php';?>
<?php require 'requires/funcionesUsuarios.php';?>	
<?php  include 'includes/header.html';  ?>
<?php  include 'includes/nav.php';  ?>
<?php $chequeo = agregarUsuario();?>

<main class="container">
    <h1>Panel de Usuarios</h1>
<?php 

	if($chequeo){}
?>
	<div class="alert alert-success" role="alert">
  Te has Registrado con exito	
</div>
<a href="adminUsuarios.php" class="btn btn-light"> Volver a panel de Usuarios</a>
	
	
</main>

<?php  include 'includes/footer.php';  ?>