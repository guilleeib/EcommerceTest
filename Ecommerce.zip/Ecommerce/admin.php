<?php 
	
	  
	  include 'includes/header.html';  
	  
	  include 'includes/nav.php';

	  require 'requires/autenticar.php';
	  include 'includes/sideNav.php';
	  require 'requires/conexion.php';
	 

?>


<main class="container">
<!-- Icon Cards-->
 <div>

 <?php

    if (isset($_GET['hola'])) {
?>
        <script>
         Swal.fire({
  position: 'center',
  type: 'success',
  title: 'Welcome',
  showConfirmButton: true,
  timer: 1500
})
        </script>

<?php
    }
    if (isset($_GET['back'])){

    
?>
 <script>
          Swal.fire({
  position: 'center',
  type: 'success',
  title: 'Welcome back',
  showConfirmButton: true,
  timer: 1500
})
        </script>
<?php
}
?>


<br>
<br>
<h1>Welcome</h1>
<br>
<br>
          <div class="row">
            <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card text-white bg-primary o-hidden h-100">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fas fa-fw fa-comments"></i>
                  </div>
                  <div class="mr-5">Usuarios</div>
                </div>
                <a class="card-footer text-white clearfix small z-1" href="adminUsuarios.php">
                  <span class="float-left">View Details</span>
                  <span class="float-right">
                    <i class="fas fa-angle-right"></i>
                  </span>
                </a>
              </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card text-white bg-warning o-hidden h-100">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fas fa-fw fa-list"></i>
                  </div>
                  <div class="mr-5">Categorias</div>
                </div>
                <a class="card-footer text-white clearfix small z-1" href="adminCategorias.php">
                  <span class="float-left">View Details</span>
                  <span class="float-right">
                    <i class="fas fa-angle-right"></i>
                  </span>
                </a>
              </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card text-white bg-success o-hidden h-100">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fas fa-fw fa-shopping-cart"></i>
                  </div>
                  <div class="mr-5">Productos</div>
                </div>
                <a class="card-footer text-white clearfix small z-1" href="adminProductos.php">
                  <span class="float-left">View Details</span>
                  <span class="float-right">
                    <i class="fas fa-angle-right"></i>
                  </span>
                </a>
              </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card text-white bg-danger o-hidden h-100">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fas fa-fw fa-life-ring"></i>
                  </div>
                  <div class="mr-5">Marcas</div>
                </div>
                <a class="card-footer text-white clearfix small z-1" href="adminMarcas.php">
                  <span class="float-left">View Details</span>
                  <span class="float-right">
                    <i class="fas fa-angle-right"></i>
                  </span>
                </a>
              </div>
            </div>
          </div>
</main>
</div>
<?php  include 'includes/footer.php';  ?>
