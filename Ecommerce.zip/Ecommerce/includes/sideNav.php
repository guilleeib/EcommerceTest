<div id="wrapper">

      <!-- Sidebar -->
      <ul class="sidebar navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="#">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-table"></i>
            <span>Tables</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <h6 class="dropdown-header">Agregar a Tablas</h6>
            <a class="dropdown-item" href="formAgregarProducto.php"> Productos</a>
            <a class="dropdown-item" href="formAgregarUsuario.php"> Usuarios</a>
            <a class="dropdown-item" href="formagregarMarca.php"> Marcas</a>
            <a class="dropdown-item" href="formAgregarCategorias.php"> Categorias</a>
            <div class="dropdown-divider"></div>
            <h6 class="dropdown-header">Modificar Tablas</h6>
            <a class="dropdown-item" href="formModificarProductos.php">Productos</a>
            <a class="dropdown-item" href="formModificarUsuarios.php">Usuarios</a>
            <a class="dropdown-item" href="formModificarMarcas.php">Marcas</a>
            <a class="dropdown-item" href="formModificarCategorias.php">Categorias</a>
            <div class="dropdown-divider"></div>
            <h6 class="dropdown-header">Eliminar Tablas</h6>
            <a class="dropdown-item" href="formEliminarProducto.php">Productos</a>
            <a class="dropdown-item" href="formEliminarUsuarios.php">Usuarios</a>
            <a class="dropdown-item" href="formEliminarMarca.php">Marcas</a>
            <a class="dropdown-item" href="formEliminarCategorias.php">Categorias</a>
          </div>
        </li>
          <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-folder"></i>
            <span>Pages</span>
            <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <h6 class="dropdown-header">Pages</h6>
            <a class="dropdown-item" href="index.php"> Inicio</a>
            <a class="dropdown-item" href="catalogo.php">Catalogo</a>
            <a class="dropdown-item" href="aboutUs.php">About Us</a>
            <a class="dropdown-item" href="#"> Contact us</a>
 
      </ul>
   