

<nav class="site-header sticky-top py-2">
    <div class="container d-flex flex-column flex-md-row justify-content-between">
        <a href="index.php" class="mt-1">
            <i class="fab fa-meetup fa-2x"></i>
        </a>

        <a class="py-2" href="index.php">Inicio</a>
        <a class="py-2" href="catalogo.php">Catalogo</a>
        <a class="py-2" href="aboutUs.php">About Us</a>
        <a class="py-2" href="formContactUs.php">Contact</a>

        
        
    <button class="btn btn-dark dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
     <a href="formLogin.php"><i class="fas fa-sign-in-alt"></i> Ingresar</a>
    </button>
    <div class="dropdown-menu">
  <form action="login.php" method="POST" class="px-4 py-3" >
    <div class="form-group">
      <label for="exampleDropdownFormEmail1">Email address</label>
      <input type="email" class="form-control" name="usuEmail" id="exampleDropdownFormEmail1" placeholder="email@example.com">
    </div>
    <div class="form-group">
      <label for="exampleDropdownFormPassword1">Password</label>
      <input type="password" class="form-control" name="usuPass" id="exampleDropdownFormPassword1" placeholder="Password">
    </div>
    <div class="form-check">
      <input type="checkbox" class="form-check-input" id="dropdownCheck">
      <label class="form-check-label" for="dropdownCheck">
        Remember me
      </label>
    </div>
    <button type="submit" class="btn btn-primary">Sign in</button>
  </form>
  <div class="dropdown-divider"></div>
  <a class="dropdown-item" href="formAgregarUsuarios2.php">New around here? Sign up</a>
  <a class="dropdown-item" href="formRecuperarPass.php">Forgot password?</a>
</div>
    
    </div>
</nav>
