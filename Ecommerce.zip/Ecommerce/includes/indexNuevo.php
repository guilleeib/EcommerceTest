<?php include 'nav.php';
	  include 'footer.php';
?>