<?php
require "requires/conexion.php";
require "requires/funcionesUsuarios.php";
include 'includes/nav.php';
?>
<?php  include 'includes/header.html';  ?>
<?php  include 'includes/nav.php';  ?>

<?php 

	if(isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header('location:logout.php');
}
?>
<h1 class="container">USTED SE HA SALIDO CORRECTAMENTE</h1>
<a href="admin.php" class="btn btn-outline-secondary m-3">Volver a principal</a>
<?php  include 'includes/footer.php';  ?>