x<?php
        require 'requires/conexion.php';
        require 'requires/funcionesProductos.php';
        $detalle = verProductoPorId();

        include 'includes/header.html';
        include 'includes/nav.php';
?>

    <main class="container">
        

        <div class="card border-danger mb-3 col-md-6 mx-auto">
            <div class="card-header">
                <h1>Confirmación de baja de un producto</h1>                
            </div>
            <div class="card-body text-danger">
                <h5 class="card-title"><?php echo $detalle['prdNombre']; ?></h5>
                Imagen:
                <img src="images/productos/<?php echo $detalle['prdImagen']; ?>" alt="">
                <br>
                Precio: <?php echo $detalle['prdPrecio'] ?>
                <br>
                Marca: <?php echo $detalle['mkNombre'] ?>
                <br>
                Categoría: <?php echo $detalle['catNombre'] ?>
                <br>
                Presentación: <?php echo $detalle['prdPresentacion'] ?>
                <br>
                <form action="eliminarProducto.php" method="post">

                    <input type="hidden" name="idProducto" value="<?php echo $detalle['idProducto'];?>">
                    <input type="submit" value="Confirmar Baja" class="btn btn-danger">
                    <a href="adminProductos.php" class="btn btn-secondary">Volver a Panel</a>

                </form>



            </div>
        </div>

        <script>
            Swal({
                title: '¿desea eliminar el producto?',
                text: "Esta acción no se puede deshacer",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#30d685',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Confirmo'
            }).then((result) => {
                if (!result.value) {
                    window.location = 'adminProductos.php'
                }
            })
        </script>


    </main>

<?php  include 'includes/footer.php';  ?>