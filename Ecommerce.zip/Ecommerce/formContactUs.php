<?php  include 'includes/headerIndex.html';  ?>
<?php  include 'includes/navIndex.php';  ?>
<main class="container">
<form id="cont-form" method="post" action="sent.php">
<fieldset>
<legend>Send me a message</legend>
<ol>
    <ul>
        <label for="name">Name</label>
        <input id="name" name="name" type="text" placeholder="First and last name" required autofocus  class="form-control">
    </ul>
    <ul>
        <label for="email">Email</label>
        <input id="email" name="email" type="email" placeholder="example@domain.com" required class="form-control">
    </ul>
    <ul>
        <label for="subject">Subject</label>
        <input id="subject" name="subject" type="text" placeholder="What the message is about" required class="form-control">
    </ul>

    <ul>
    <label for="message">Message</label>
    <textarea id="message" name="message" placeholder="Insert your message or question here" rows="10" cols="50" class="form-control">
    </textarea>
    </ul>
    </ol>
</fieldset>
<fieldset>
  <input type="submit" name="submit" value="Send Message" class="btn btn-secondary">
</fieldset>
</form>
</main>
<?php  include 'includes/footer.php';  ?>