<?php
//directiva de sesion
session_start();
//registramos variables de sesion
 $_SESSION['nombre']='gui';
 $_SESSION['numero']= 5;
 $_SESSION['Fruta']= 'frutilla';
