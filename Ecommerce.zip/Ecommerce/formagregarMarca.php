<?php  include 'includes/header.html';  ?>
<?php  include 'includes/nav.php';  ?>

<main class="container">
    <h1>Alta de Marca</h1>

    <form action="agregarMarcas.php" method="post">Marca:
    <br>
    <input type="text" name="mkNombre" class="form-control">
    <br>
    <input type="submit" value="Agregar marca" class="btn btn-secondary">
    <a href="adminMarcas.php" class=btn btn-light>Volver a panel de marcas</a>
    </form>


