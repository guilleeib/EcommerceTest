<?php
    require 'requires/conexion.php';
    require 'requires/funcionesProductos.php';
    $listadoProductos = listarProductos();
    
?>

<?php  include 'includes/headerIndex.html';  ?>
<?php  include 'includes/navIndex.php';  ?>

<main class="container">
    <h1>Catalogo</h1>

    <a href="admin.php" class="btn btn-outline-secondary m-3">Volver a principal</a>

    <table class="table table-stripped table-hover table-border">
        <thead class="thead-dark">
            <tr>
                <th>Nombre</th>
                <th>Marca</th>
                <th>Categoria</th>
                <th>Presentacion</th>
                <th>Imagen</th>
                <th>Precio</th>
                <th colspan="2">
               
                </th>
            </tr>
        </thead>
        <tbody>
<?php
        while( $fila = mysqli_fetch_assoc($listadoProductos) ){
?>
            <tr>
            
                <td><?php echo $fila['prdNombre']; ?><span class="badge badge-secondary">New</span></td>
                <td><?php echo $fila['mkNombre']; ?></td>
                <td><?php echo $fila['catNombre']; ?></td>
                <td><?php echo $fila['prdPresentacion']; ?></td>
                <td>
                    <img src="images/productos/<?php echo $fila['prdImagen']; ?>" class="img-thumbnail img50">
                </td>
               <td><?php echo $fila['prdPrecio']; ?><span class="badge badge-danger">50%OFF</span></td>
              
            </tr>
<?php
        }
?>
        </tbody>
    </table>
    <nav aria-label="...">
  <ul class="pagination">
    <li class="page-item disabled">
      <a class="page-link" href="#" tabindex="-1">Previous</a>
    </li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item active">
      <a class="page-link" href="#">2 <span class="sr-only">(current)</span></a>
    </li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item">
      <a class="page-link" href="#">Next</a>
    </li>
  </ul>
</nav>

    <br>

</main>

<?php  include 'includes/footer.php';  ?>