<?php  include 'includes/header.html';  ?>
<?php  include 'includes/nav.php';  ?>
<?php require 'requires/conexion.php'; 
	  require 'requires/funcionesUsuarios.php';
	  $listadoUsuarios = listarUsuarios();
require 'requires/autenticar.php';
	   ?>

<main class="container">
    <h1>Panel de administracion de Usuarios</h1>
    <a href="admin.php?back=1" class="btn btn-outline-secondary m-3">Volver a principal</a>

	<table class="table table-stripped table-bordered table-hover">
		<thead class="thead-dark">
			<tr>
				<th>id</th>
				<th>Nombre</th>
				<th>Apellido</th>
				<th>Email</th>
				<th>Password</th>
				<th>Estado</th>
				<th colspan="2"></th>
			</tr>
		</thead>
		<tbody>
<?php
while ( $fila = mysqli_fetch_assoc($listadoUsuarios)) {


 ?>
			<tr>
				<td><?php echo $fila['idUsuario'];?></td>
				<td><?php echo $fila['usuNombre'];?></td>
				<td><?php echo $fila['usuApellido'];?></td>
				<td><?php echo $fila['usuEmail'];?></td>
				<td><?php echo $fila['usuPass'];?></td>
				<td><?php echo $fila['usuEstado'];?></td>
			

				<td><a href="formModificarUsuarios.php?idUsuario=<?php echo $fila['idUsuario'];?>" class="btn btn-secondary">Modificar</a></td>
				<td><a href="formEliminarUsuarios.php?idUsuario=<?php echo $fila['idUsuario'];?>" class="btn btn-secondary">Borrar</a></td>
			</tr>
<?php 
}
?>
		</tbody>
	</table>

</main>

<?php  include 'includes/footer.php';  ?>