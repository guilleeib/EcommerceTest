<?php 
	  include 'includes/header.html';  
	  include 'includes/nav.php';  
	  require 'requires/autenticar.php';
	
?>
<?php require 'requires/conexion.php'; 
	  require 'requires/funcionesCategorias.php';
	  $listadoCategorias = listarCategorias(); 
	
?>

<main class="container">
    <h1>Panel de administracion de Categorias</h1>
    <a href="admin.php?back=1" class="btn btn-outline-secondary m-3">Volver a principal</a>

	<table class="table table-stripped table-bordered table-hover">
		<thead class="thead-dark">
			<tr>
				<th>id</th>
				<th>Categoria</th>
				<th colspan="2"><a href="formAgregarCategorias.php" class="btn btn-dark">Agregar</a></th>
			</tr>
		</thead>
		<tbody>
<?php
while ( $fila = mysqli_fetch_assoc($listadoCategorias)) {


 ?>
			<tr>
				<td><?php echo $fila['idCategoria'];?></td>
				<td><?php echo $fila['catNombre'];?></td>
				<td><a href="formModificarCategorias.php?idCategoria=<?php echo $fila['idCategoria'];?>" class="btn btn-secondary">Modificar</a></td>
				<td><a href="formEliminarCategorias.php?idCategoria=<?php echo $fila['idCategoria'];?>" class="btn btn-secondary">Borrar</a></td>
			</tr>
<?php 
}
?>
		</tbody>
	</table>

</main>

<?php  include 'includes/footer.php';  ?>