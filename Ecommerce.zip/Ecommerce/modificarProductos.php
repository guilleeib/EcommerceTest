<?php require 'requires/conexion.php';?>
<?php require 'requires/funcionesProductos.php';?> 
<?php  include 'includes/header.html';  ?>
<?php  include 'includes/nav.php';  ?>
<?php $chequeo = modificarProducto();?>

<main class="container">
    <h1>Modificacion de Producto</h1>
<?php 

    if($chequeo){}
?>
    <div class="alert alert-succes">Producto modificado con Exito<a href="adminMarcas.php" class="btn btn-light"> Volver a panel </a>
    </div>  
    
</main>

<?php  include 'includes/footer.php';  ?>