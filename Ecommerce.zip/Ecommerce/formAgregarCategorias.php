<?php  
	   require 'requires/conexion.php';
	   require 'requires/funcionesCategorias.php';
	   include 'includes/header.html';  ?>
<?php  include 'includes/nav.php'; 
	  
 ?>

<main class="container">
    <h1>Alta de Categorias</h1>

    <form action="agregarCategorias.php" method="post" enctype="multipart/form-data">
        Nombre: <br>
        <input type="text" name="catNombre" value="" class="form-control" required>
        <br>
   
    <input type="submit" value="Agregar Categoria" class="btn btn-secondary">
    <a href="adminCategorias.php" class=btn btn-light>Volver a panel de categorias</a>
    </form>
</main>

<?php  include 'includes/footer.php';  ?>