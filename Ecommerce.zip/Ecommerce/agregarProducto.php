<?php
    require 'requires/conexion.php';
    require 'requires/funcionesProductos.php';

    $chequeo = agregarProducto();

    include 'includes/header.html';
    include 'includes/nav.php';
?>

    <main class="container">
        <h1>Alta de unnuevo producto</h1>
<?php
        if( $chequeo ){
            ?>
            <div class="alert alert-success">
                Producto agregado con éxito
                <a href="adminProductos.php" class="btn btn-light">Volver a panel</a>
                <a href="formAgregarProducto.php" class="btn btn-light">Agregar otro Producto</a>
            </div>
            <?php
        }
        else{
            ?>
            <div class="alert alert-danger">
                No se ha agregado el producto
                <a href="adminProductos.php" class="btn btn-light">Volver a panel</a>
            </div>
            <?php
        }
?>
    </main>

<?php  include 'includes/footer.php';  ?>