<?php  
require 'requires/conexion.php';
include 'includes/header.html';  ?>
<?php  include 'includes/nav.php'; 
	   require 'requires/funcionesMarcas.php'; ?>
<?php $verID=verMarcaPorID();?>

<main class="container">
    <h1>Modificacion de Marca</h1>

    <form action="modificarMarcas.php" method="post" enctype="multipart/form-data">
        Nombre: <br>
        <input type="text" name="catNombre" value="<?php echo $verID['mkNombre']; ?>" class="form-control" required>
        <br>
    <input type="hidden" name="idMarca" value="<?php echo $verID['idMarca']; ?>">
    <input type="submit" value="Modificar marca" class="btn btn-secondary">
    <a href="adminMarcas.php" class=btn btn-light>Volver a panel de marcas</a>
    </form>