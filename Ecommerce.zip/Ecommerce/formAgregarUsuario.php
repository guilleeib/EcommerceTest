<?php  include 'includes/header.html';  ?>
<?php  include 'includes/nav.php';  ?>

<main class="container">
    <h1>Alta de Usuarios</h1>

    <form action="agregarUsuarios.php" method="post">Nombre:
    <br>
        <input type="text" name="usuNombre" class="form-control">
    <br>
    <form action="agregarUsuarios.php" method="post">Apellido:
    	<input type="text" name="usuApellido" class="form-control">
    <br>
    <form action="agregarUsuarios.php" method="post">Email:
    <br>
    <input type="text" name="usuEmail" class="form-control">
    <br>
    <form action="agregarUsuarios.php" method="post">Password:
    <br>
    <input type="text" name="usuPass" class="form-control">
    <br>
    <input type="submit" value="Agregar Usuario" class="btn btn-secondary">
    <a href="adminUsuarios.php" class=btn btn-light>Volver a panel de Usuarios</a>
    </form>


