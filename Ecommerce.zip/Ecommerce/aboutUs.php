<?php  include 'includes/headerIndex.html';  ?>
<?php  include 'includes/navIndex.php'; ?>


<main class="container">

 <div class="jumbotron">
  <h1 class="display-4">Hello, world!</h1>
  <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur suscipit illo recusandae deserunt aliquam nesciunt, sint, at sed illum soluta error odio, necessitatibus. Quos repellat excepturi dolor. Aliquid enim totam maxime provident, nihil distinctio modi cumque fugit, placeat ratione assumenda error vel cupiditate natus! In debitis non, ex placeat blanditiis. Vel incidunt voluptatibus rerum nihil, amet est, quasi quae cumque omnis eum, obcaecati aut, ratione illum quis deleniti sequi debitis ullam error culpa nobis sit corrupti atque. Autem ducimus numquam enim tempore laboriosam labore nisi illo fuga dolor, sapiente ab doloribus. Consequuntur velit culpa saepe quia fugit, impedit illum iure!.</p>
  <hr class="my-4">
  <p>It uses utility classes for typography and spacing to space content out within the larger container.</p>
  <a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
</div>
    </main>
<?php  include 'includes/footer.php';  ?>