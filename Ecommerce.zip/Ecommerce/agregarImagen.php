
<?php

if($_FILES['prdImagen']['error']==0){
	$prdImagen = $_FILES['prdImagen']['name'];
	$prdImagenTMP= $_FILES['prdImagen']['tmp_name'];
	move_uploaded_file($prdImagenTMP, $ruta.$prdImagen);
}
?>
<img scr="fotos/<?php echo $prdImagen; ?>">