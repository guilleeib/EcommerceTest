<?php  include 'includes/header.html';  ?>
<?php  include 'includes/nav.php';  ?>
<?php

if(isset($_FILES['archivo'])){
	$subidaOk= $_FILES['archivo']['error']== upload_err_ok;
	if($subidaOk){
		$esImagen= getimagesize($_FILES['archivo']['tmp_name']);
		if($esImagen){
			move_uploaded_file($_FILES['archivo']['tmp_name'],'upload/'.$_FILES['archivo']['name']);
		}
		$upload=TRUE;
	}
} 
?>


<main class="container">
    <h1>Agregar Imagen</h1>

<form method="POST" action="" enctype="multipart/form-data" >
<input type="file" name="archivo">
<input type="submit" value="Subir Archivo">
</form>

</main>

<?php  include 'includes/footer.php';  ?>