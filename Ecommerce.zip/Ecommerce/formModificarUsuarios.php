<?php  
require 'requires/conexion.php';
include 'includes/header.html';  ?>
<?php  include 'includes/nav.php'; 
	   require 'requires/funcionesUsuarios.php'; ?>
<?php $verID=verUsuarioPorID();?>

<main class="container">
    <h1>Modificacion de Usuarios</h1>

    <form action="modificarUsuarios.php" method="post" enctype="multipart/form-data">
        Nombre: <br>
        <input type="text" name="usuNombre" value="<?php echo $verID['usuNombre']; ?>" class="form-control" required>
        <br>
        Apellido:
        <input type="text" name="usuApellido" value="<?php echo $verID['usuApellido']; ?>" class="form-control" required>
        <br>
        Email:
        <input type="text" name="usuEmail" value="<?php echo $verID['usuEmail']; ?>" class="form-control" required>
        <br>
        Password
        <input type="text" name="usuPass" value="<?php echo $verID['usuPass']; ?>" class="form-control" required>
        <br>
        Estado:(1= Activo 0=Inactivo)
        <input type="text" name="usuEstado" value="<?php echo $verID['usuEstado']; ?>" class="form-control" required>
        <br>
    <input type="hidden" name="idUsuario" value="<?php echo $verID['idUsuario']; ?>">
    <input type="submit" value="Modificar Usuario" class="btn btn-secondary">
    <a href="adminUsuarios.php" class=btn btn-light>Volver a panel de Usuarios</a>
    </form>