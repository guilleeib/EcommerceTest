<?php
include 'includes/headerIndex.html';  
include 'includes/navIndex.php';
require "requires/conexion.php";
require "requires/funcionesUsuarios.php";


$recuperarPass= recuperarPass();
$pass = mysqli_fetch_assoc($recuperarPass)
 ?>
<main class="container">
	
	<h1>Password</h1>
<br>
<br>
<div class="alert alert-success" role="alert">
  Su Password es : <?php echo $pass['usuPass'];?>
</div>
</main>

<?php  include 'includes/footer.php';  ?>