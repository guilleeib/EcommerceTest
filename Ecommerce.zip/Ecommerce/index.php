<?php  include 'includes/headerIndex.html';  ?>
<?php  include 'includes/navIndex.php';  ?>

<main class="container">
	<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-4">Ecommerce</h1>
    <p class="lead">Encuentra aqui nuestra variada seccion de venta de electronica.</p>
  </div>
</div>
<div class="card-deck">
  <div class="card">
    <img class="card-img-top" src="images/productos/P001.jpg" alt="hola">
    <div class="card-body">
      <h5 class="card-title">Smartphones</h5>
      <p class="card-text">Encuentra aqui nuestros ofertas en Smartphones</p>
      <a href="catalogo.php" class="btn btn-primary">Ver mas</a>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="images/productos/P002.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Tablets</h5>
      <p class="card-text">Encuentra aqui nuestras ofertas en Tablets</p>
      <a href="catalogo.php" class="btn btn-primary">Ver mas</a>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="images/productos/P007.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">SmartWhatches</h5>
      <p class="card-text">Encuentra aqui nuestras ofertas en SmartWatches</p>
      <a href="catalogo.php" class="btn btn-primary">Ver mas</a>
    </div>
  </div>
</div>

<?php  include 'includes/footer.php';  ?>