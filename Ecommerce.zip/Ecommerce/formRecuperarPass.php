<?php  include 'includes/header.html';  ?>
<?php  include 'includes/nav.php';  ?>

<main class="container">
    <h1>Recuperar Password</h1>
	<p>Ingresa tu Email para poder recuperar tu password.</p>
	<br>
    <form action="recuperarPass.php" method="post">Email
    <br>
    <input type="text" name="usuEmail" class="form-control">
    <br>
    <input type="submit" value="Recuperar Password" class="btn btn-secondary">
    <a href="formLogin.php" class=btn btn-light>Volver a Login</a>
    </form>
    </main>
<?php  include 'includes/footer.php';  ?>