<?php  include 'includes/header.html';  ?>
<?php  include 'includes/nav.php';  ?>
<?php require 'requires/conexion.php'; 
	  require 'requires/funcionesMarcas.php';
	  require 'requires/autenticar.php';
	  $listadomarcas = listarMarcas(); 
	  
	  ?>

<main class="container">
    <h1>Panel de administracion de Marcas</h1>
    <a href="admin.php?back=1" class="btn btn-outline-secondary m-3">Volver a principal</a>

	<table class="table table-stripped table-bordered table-hover">
		<thead class="thead-dark">
			<tr>
				<th>id</th>
				<th>Marca</th>
				<th colspan="2"><a href="formagregarMarca.php" class="btn btn-dark">Agregar</a></th>
			</tr>
		</thead>
		<tbody>
<?php
while ( $fila = mysqli_fetch_assoc($listadomarcas)) {


 ?>
			<tr>
				<td><?php echo $fila['idMarca'];?></td>
				<td><?php echo $fila['mkNombre'];?></td>
				<td><a href="formModificarMarca.php?idMarca=<?php echo $fila['idMarca'];?>" class="btn btn-secondary">Modificar</a></td>
				<td><a href="formEliminarMarca.php?idMarca=<?php echo $fila['idMarca'];?>" class="btn btn-secondary">Borrar</a></td>
			</tr>
<?php 
}
?>
		</tbody>
	</table>

</main>

<?php  include 'includes/footer.php';  ?>