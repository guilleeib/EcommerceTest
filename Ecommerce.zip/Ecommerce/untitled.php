<?php  include 'includes/header.html';  ?>
<?php  include 'includes/navIndex.php';  ?>

<main class="container">
    <h1>Alta de Productos</h1>

   
    </main>
<?php  include 'includes/footer.php';  ?>