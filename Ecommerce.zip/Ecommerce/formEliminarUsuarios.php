
<?php require 'requires/conexion.php';?>
<?php  include 'includes/header.html';  ?>
<?php  include 'includes/nav.php'; ?>
<?php  require 'requires/funcionesUsuarios.php'; ?>

        <?php  $verID= verUsuarioPorID();?>

<main class="container">
<div class="card border-danger mb-3 col-md-6 mx-auto">
            <div class="card-header">
                <h1>Confirmación de baja de un Usuario</h1>                
            </div>
            <div class="card-body text-danger">
                Nombre: <?php echo $verID['usuNombre']; ?>
                <br>
                Apellido:
                 <?php echo $verID['usuApellido']; ?>
                <br>
                Email:
                 <?php echo $verID['usuEmail']; ?>
                <br>
                
                <form action="eliminarUsuarios.php" method="post">
                    
                     <input type="hidden" name="idUsuario" value="<?php echo $verID['idUsuario']; ?>">               
                    <input type="submit" value="Confirmar Baja" class="btn btn-success">
                    <a href="formModificarEstado.php?idUsuario=<?php echo $verID['idUsuario'];?>" class="btn btn-danger">Cambiar Estado</a>
                    <a href="adminUsuarios.php" class="btn btn-secondary">Volver a Panel</a>
                    
   

<script>
            Swal({
                title: '¿desea eliminar el usuario?',
                text: "Se recomienda cambiar el estado del usuario",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#30d685',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Confirmo'
            }).then((result) => {
                if (!result.value) {
                    window.location = 'adminUsuarios.php'
                }
            })
        </script>

    </main>

<?php  include 'includes/footer.php';  ?>