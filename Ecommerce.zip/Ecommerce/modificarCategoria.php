<?php require 'requires/conexion.php';?>
<?php require 'requires/funcionesCategorias.php';?>	
<?php  include 'includes/header.html';  ?>
<?php  include 'includes/nav.php';  ?>
<?php $chequeo = modificarCategorias();?>

<main class="container">
    <h1>Modificar Marcas</h1>
<?php 

	if($chequeo){}
?>
	<div class="alert alert-succes">Categoria modificada con Exito<a href="adminMarcas.php" class="btn btn-light"> Volver a panel </a>
	</div>	
	
</main>

<?php  include 'includes/footer.php';  ?>