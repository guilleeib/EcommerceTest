<?php require "requires/funcionesUsuarios.php";?>
<?php  include 'includes/header.html';  ?>
<?php  include 'includes/nav.php'; ?>
 <?php logout(); ?>
 <main class="container">
   
    <div>
<script>
 Swal.fire({
  position: 'center',
  type: 'success',
  title: 'Has salido correctamente',
  showConfirmButton: true,
  timer: 1500
})
 </script>
</div>
<br>

<div class="alert alert-success" role="alert">
  Has salido correctamente
</div>
    <a href="formLogin.php" class="btn btn-light">Volver a Login</a>
    <a href="index.php" class="btn btn-light">Volver al Inicio</a>
    </form>
    </main>
<?php  include 'includes/footer.php';  ?>




