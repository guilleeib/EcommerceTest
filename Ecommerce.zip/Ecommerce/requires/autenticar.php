<?php
session_start();
if ( !isset($_SESSION['login'])){
    header('location:formLogin.php?ingresar=1');
}