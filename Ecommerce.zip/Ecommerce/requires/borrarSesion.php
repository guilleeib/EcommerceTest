<?php 

	if(isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['login']);
    header('location:../logout.php');
    
}