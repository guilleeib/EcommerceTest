<?php 

function listarUsuarios(){
	$link= conectar();
	$sql= "SELECT idUsuario,usuNombre,usuApellido,usuEmail,usuPass,usuEstado FROM usuarios";
	$resultado= mysqli_query($link, $sql);
	return $resultado;
}

function agregarUsuario(){
	$usuNombre = $_POST['usuNombre'];
	$usuApellido = $_POST['usuApellido'];
	$usuEmail = $_POST['usuEmail'];
	$usuPass = $_POST ['usuPass'];
	$link= conectar();
	$sql= "INSERT INTO usuarios ( usuNombre, usuApellido, usuEmail, usuPass, usuEstado) VALUES ('".$usuNombre."','".$usuApellido."','".$usuEmail."','".$usuPass."',1)";
	$resultado=mysqli_query($link, $sql) or die(mysqli_error($link));
	return $resultado;
}
function login ()
{
    $usuEmail = $_POST['usuEmail'];
    $usuPass = $_POST['usuPass'];
    $idUsuario=$_POST['idUsuario'];
   //$ruta= "192.168.64.2/guigui/admin.php?idUsuario=";
    $link = conectar();
    $sql = "SELECT 1 FROM usuarios 
            WHERE usuEmail ='" . $usuEmail . "'
            AND usuPass='" . $usuPass . "'
            AND usuEstado= 1";
    $resultado = mysqli_query($link, $sql) or die (mysqli_error($link));
    $cantidad= mysqli_num_rows($resultado);
    if ($cantidad == 0){
        // redireccion a formLogin.php
        header('location: formLogin.php?error=1');
    }else{
        #### rutina de autenticacion#####
        session_start();
        $_SESSION['login']=1;
        //redireccion a admin
        header('Location:admin.php?hola=1');
      //  header('Location:admin.php?usuEmail='.$usuEmail); ###redireccion mostrando el nombre en el admin

    }
}
 function logout()

{


    if(isset($_GET['logout'])) {
    session_start();
    session_destroy();
    unset($_SESSION['login']);
    
    
}
}
function verUsuarioPorID()
    {
        $idUsuario = $_GET['idUsuario'];
        $link = conectar();
        $sql = "SELECT idUsuario,usuNombre,usuApellido,usuEmail,usuEstado,usuPass
                FROM usuarios
                WHERE idUsuario= ".$idUsuario ;
        $resultado = mysqli_query($link, $sql)
                        or die(mysqli_error($link));

        $verID = mysqli_fetch_assoc($resultado);
        return $verID;
    }
function eliminarUsuarios()
    {
        $idUsuario = $_POST['idUsuario'];
        $link = conectar();
        $sql = "DELETE FROM usuarios WHERE usuarios.idUsuario = ".$idUsuario;
        $resultado = mysqli_query($link, $sql)
                                or die(mysqli_error($link));
        return $resultado;
    }

  function modificarUsuarios()
    {
        $idUsuario = $_POST['idUsuario'];
        $usuNombre=$_POST['usuNombre'];
        $usuApellido=$_POST['usuApellido'];
        $usuEmail=$_POST['usuEmail'];
        $usuPass=$_POST['usuPass'];
        $usuEstado=$_POST['usuEstado'];
        $link = conectar();
        $sql ="UPDATE usuarios 
                  SET usuNombre = '".$usuNombre."',usuApellido = '".$usuApellido."',usuEmail = '".$usuEmail."',usuEstado = '".$usuEstado."',usuPass = '".$usuPass."'
               WHERE idUsuario = ".$idUsuario;
        $resultado = mysqli_query($link, $sql)
                    or die(mysqli_error($link));
        return $resultado;
    }
    function cambiarEstado(){
        $usuEstado=$_POST['usuEstado'];
        $idUsuario=$_POST['idUsuario'];
        $link = conectar();
        $sql ="UPDATE usuarios 
                  SET usuEstado = '".$usuEstado."'
               WHERE idUsuario = ".$idUsuario;
        $resultado = mysqli_query($link, $sql)
                    or die(mysqli_error($link));
        return $resultado;
    }

    function verNombrePorEmail()
    {
        $usuEmail = $_GET['usuEmail'];
        $link = conectar();
        $sql = "SELECT usuNombre FROM usuarios 
            WHERE usuEmail ='" . $usuEmail . "'
            AND usuEstado= 1";
        $resultado = mysqli_query($link, $sql)
                        or die(mysqli_error($link));

        $verNombre = mysqli_fetch_assoc($resultado);
        return $verNombre;
    }
function recuperarPass()
{

$usuEmail=$_POST['usuEmail'];
$link = conectar();
$sql= "SELECT usuPass FROM usuarios WHERE usuEmail='".$usuEmail."'";
       $resultado = mysqli_query($link, $sql)
                        or die(mysqli_error($link));

      
        return $resultado;

}
    
 ?>


