<?php 

function listarCategorias(){
	$link= conectar();
	$sql= "SELECT idCategoria,catNombre FROM categorias";
	$resultado= mysqli_query($link, $sql);
	return $resultado;
}
function verCategoriaPorID(){
    
    $idCategoria= $_GET['idCategoria'];
    $link= conectar();
    $sql= "SELECT idCategoria, catNombre FROM categorias WHERE idCategoria=".$idCategoria;
    $resultado = mysqli_query($link, $sql)
                        or die(mysqli_error($link));

        $verID = mysqli_fetch_assoc($resultado);
        return $verID;

}

function agregarCategoria()
    {
        
        $catNombre = $_POST['catNombre'];
        $link = conectar();
        $sql = "INSERT INTO categorias 
                    VALUES
                      ( 
                        NULL,  
                        '".$catNombre."'
                       )   
                ";
        $resultado = mysqli_query($link, $sql)
                            or die(mysqli_error($link));
        return $resultado;
 
    }


function modificarCategorias()
    {
        $idCategoria = $_POST['idCategoria'];
        $catNombre=$_POST['catNombre'];
        $link = conectar();
        $sql ="UPDATE categorias 
                  SET catNombre = '".$catNombre."'
               WHERE idCategoria = ".$idCategoria;
        $resultado = mysqli_query($link, $sql)
                    or die(mysqli_error($link));
        return $resultado;
    }

    function eliminarCategorias()
    {
        $idCategoria = $_POST['idCategoria'];
        $link = conectar();
        $sql = "DELETE FROM categorias WHERE categorias.idCategoria = ".$idCategoria;
        $resultado = mysqli_query($link, $sql)
                                or die(mysqli_error($link));
        return $resultado;
    }
 ?>
