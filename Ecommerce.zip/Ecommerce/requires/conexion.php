<?php 
	const SERVER = 'localhost';
	const USUARIO = 'root';
	const CLAVE = '';
	const DB= 'catalogo';

	function conectar(){
		$link = mysqli_connect(SERVER, USUARIO, CLAVE, DB);
	return $link;
	}
 ?>