
<?php require 'requires/conexion.php';?>
<?php  include 'includes/header.html';  ?>
<?php  include 'includes/nav.php'; ?>
<?php  require 'requires/funcionesCategorias.php'; ?>

        <?php  $verID= verCategoriaPorID();?>

<main class="container">
<div class="card border-danger mb-3 col-md-6 mx-auto">
            <div class="card-header">
                <h1>Confirmación de baja de una Categoria</h1>                
            </div>
            <div class="card-body text-danger">
                Marca: <?php echo $verID['catNombre']; ?>
                <br>
                <br>
                <form action="eliminarCategorias.php" method="post">

                     <input type="hidden" name="idCategoria" value="<?php echo $verID['idCategoria']; ?>">               
                    <input type="submit" value="Confirmar Baja" class="btn btn-danger">
                    <a href="adminCategorias.php" class="btn btn-secondary">Volver a Panel</a>
   

<script>
            Swal({
                title: '¿desea eliminar la Categoria?',
                text: "Esta acción no se puede deshacer",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#30d685',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Confirmo'
            }).then((result) => {
                if (!result.value) {
                    window.location = 'adminCategorias.php'
                }
            })
        </script>

    </main>

<?php  include 'includes/footer.php';  ?>