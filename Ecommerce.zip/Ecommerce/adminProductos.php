<?php
    require 'requires/conexion.php';
    require 'requires/funcionesProductos.php';
    $listadoProductos = listarProductos();
    require 'requires/autenticar.php';
?>
<?php  include 'includes/header.html';  ?>
<?php  include 'includes/nav.php';  ?>

<main class="container">
    <h1>Panel de administración de productos</h1>

    <a href="admin.php?back=1" class="btn btn-outline-secondary m-3">Volver a principal</a>

    <table class="table table-stripped table-hover table-border">
        <thead class="thead-dark">
            <tr>
                <th>Nombre</th>
                <th>Precio</th>
                <th>Marca</th>
                <th>Categoria</th>
                <th>Presentación</th>
                <th>Imagen</th>
                <th colspan="2">
                    <a href="formAgregarProducto.php" class="btn btn-dark">
                        Agregar
                    </a>
                </th>
            </tr>
        </thead>
        <tbody>
<?php
        while( $fila = mysqli_fetch_assoc($listadoProductos) ){
?>
            <tr>
            
                <td><?php echo $fila['prdNombre']; ?></td>
                <td><?php echo $fila['prdPrecio']; ?></td>
                <td><?php echo $fila['mkNombre']; ?></td>
                <td><?php echo $fila['catNombre']; ?></td>
                <td><?php echo $fila['prdPresentacion']; ?></td>
                <td>
                    <img src="images/productos/<?php echo $fila['prdImagen']; ?>" class="img-thumbnail img50">
                </td>
                <td>
                    <a href="formModificarProducto.php?idProducto=<?php echo $fila['idProducto'];?>" class="btn btn-outline-secondary">
                        modificar
                    </a>
                </td>
                <td>
                    <a href="formEliminarProducto.php?idProducto=<?php echo $fila['idProducto'];?>" class="btn btn-outline-secondary">
                        eliminar
                    </a>
                </td>
            </tr>
<?php
        }
?>
        </tbody>
    </table>

    <a href="admin.php" class="btn btn-outline-secondary m-3">Volver a principal</a>

</main>

<?php  include 'includes/footer.php';  ?>