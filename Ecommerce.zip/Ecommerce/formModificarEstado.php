
<?php require 'requires/conexion.php';?>
<?php  include 'includes/header.html';  ?>
<?php  include 'includes/nav.php'; ?>
<?php  require 'requires/funcionesUsuarios.php'; ?>

        <?php  $verID= verUsuarioPorID();?>

<main class="container">
<div class="card border-danger mb-3 col-md-6 mx-auto">
            <div class="card-header">
                <h1>Confirmación de Cambio de Estado</h1>                
            </div>
            <div class="card-body text-danger">
                
                
                
                <form action="cambiarEstado.php" method="post">
                    Estado: 
                <input type="text" name="usuEstado" value="<?php echo $verID['usuEstado']; ?>">
                     <input type="hidden" name="idUsuario" value="<?php echo $verID['idUsuario']; ?>">               
                    <input type="submit" value="Confirmar Baja" class="btn btn-danger">
                    <a href="adminUsuarios.php" class="btn btn-secondary">Volver a Panel</a>
   

<script>
            Swal({
                title: '¿desea cambiar el Estado?',
                text: "Esta acción no se puede deshacer",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#30d685',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Confirmo'
            }).then((result) => {
                if (!result.value) {
                    window.location = 'adminUsuarios.php'
                }
            })
        </script>

    </main>

<?php  include 'includes/footer.php';  ?>