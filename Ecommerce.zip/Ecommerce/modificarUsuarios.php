<?php require 'requires/conexion.php';?>
<?php require 'requires/funcionesUsuarios.php';?>	
<?php  include 'includes/header.html';  ?>
<?php  include 'includes/nav.php';  ?>
<?php $chequeo = modificarUsuarios();?>

<main class="container">
    <h1>Modificar Usuarios</h1>
<?php 

	if($chequeo){}
?>
	<div class="alert alert-succes"> Usuario Modificado con Exito<a href="adminUsuarios.php" class="btn btn-light"> Volver a panel </a>
	</div>	
	
</main>

<?php  include 'includes/footer.php';  ?>