<?php

	$link= mysqli_connect('localhost','root','','catalogo');//Conectarse al server (nombre del servidor, usuario,contraseña,base de datos)
	$sql= "SELECT idMarca,mkNombre FROM marcas";
	$resultado= mysqli_query($link, $sql);// funcion para mostrar mensaje en pantalla (conexion,query)
	while ($fila= mysqli_fetch_array($resultado)) 
	{echo $fila[0],' ',$fila[1],'<br>';}
	 // para imprimir un array entre [] la posicion del dato
	// while para que se imprima todo el array en pantalla 
	mysqli_close($link);

?>
